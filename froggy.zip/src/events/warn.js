module.exports = (client, info) => {
  client.logger.warn(info);
};
