const Command = require('../Command.js');
const { MessageEmbed } = require('discord.js');

module.exports = class BanCommand extends Command {
  constructor(client) {
    super(client, {
      name: 'ban',
      usage: 'ban <user mention/ID> [reason]',
      description: '從您的服務器停權成員',
      type: client.types.MOD,
      clientPermissions: ['SEND_MESSAGES', 'EMBED_LINKS', 'BAN_MEMBERS'],
      userPermissions: ['BAN_MEMBERS'],
      examples: ['ban @Nettles']
    });
  }
  async run(message, args) {

    const member = this.getMemberFromMention(message, args[0]) || message.guild.members.cache.get(args[0]);
    if (!member)
      return this.sendErrorMessage(message, 0, '請提及用戶或提供有效的用戶 ID');
    if (member === message.member)
      return this.sendErrorMessage(message, 0, '你不能停權自己'); 
    if (member.roles.highest.position >= message.member.roles.highest.position)
      return this.sendErrorMessage(message, 0, '您不能停權具有同等或更高職位的人');
    if (!member.bannable)
      return this.sendErrorMessage(message, 0, '提供的成員不能被停權');

    let reason = args.slice(1).join(' ');
    if (!reason) reason = '`None`';
    if (reason.length > 1024) reason = reason.slice(0, 1021) + '...';
    
    await member.ban({ reason: reason });

    const embed = new MessageEmbed()
      .setTitle('封鎖用户')
      .setDescription(`${member} 成功停權!`)
      .addField('.', message.member, true)
      .addField('用户', member, true)
      .addField('原因', reason)
      .setFooter(message.member.displayName,  message.author.displayAvatarURL({ dynamic: true }))
      .setTimestamp()
      .setColor(message.guild.me.displayHexColor);
    message.channel.send(embed);
    message.client.logger.info(`${message.guild.name}: ${message.author.tag} 停權 ${member.user.tag}`);
        
    // Update mod log
    this.sendModLogMessage(message, reason, { Member: member});
  }
};
