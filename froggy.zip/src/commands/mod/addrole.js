const Command = require('../Command.js');
const { MessageEmbed } = require('discord.js');

module.exports = class AddRoleCommand extends Command {
  constructor(client) {
    super(client, {
      name: 'addrole',
      aliases: ['giverole', 'addr', 'ar'],
      usage: 'addrole <用戶提及/ID> <身份組提及/ID> [原因]',
      description: '將指定的角色添加到提供的用戶。',
      type: client.types.MOD,
      clientPermissions: ['SEND_MESSAGES', 'EMBED_LINKS', 'MANAGE_ROLES'],
      userPermissions: ['MANAGE_ROLES'],
      examples: ['addrole @Nettles @Member']
    });
  }
  async run(message, args) {

    const member = this.getMemberFromMention(message, args[0]) || message.guild.members.cache.get(args[0]);
    if (!member)
      return this.sendErrorMessage(message, 0, '請提及用戶或提供有效的用戶 ID');
    if (member.roles.highest.position >= message.member.roles.highest.position)
      return this.sendErrorMessage(message, 0, '他/她的權限比我高！');

    const role = this.getRoleFromMention(message, args[1]) || message.guild.roles.cache.get(args[1]);
    
    let reason = args.slice(2).join(' ');
    if (!reason) reason = '`None`';
    if (reason.length > 1024) reason = reason.slice(0, 1021) + '...';

    if (!role)
      return this.sendErrorMessage(message, 0, '請提及身份組或提供有效的身份組 ID');
    else if (member.roles.cache.has(role.id)) // If member already has role
      return this.sendErrorMessage(message, 0, '該成員已擁有此身份組');
    else {
      try {

        // Add role
        await member.roles.add(role);
        const embed = new MessageEmbed()
          .setTitle('加入身份組')
          .setDescription(`${role} 成功給予 ${member}`)
          .addField('', message.member, true)
          .addField('成員', member, true)
          .addField('身份組', role, true)
          .addField('原因', reason)
          .setFooter(message.member.displayName,  message.author.displayAvatarURL({ dynamic: true }))
          .setTimestamp()
          .setColor(message.guild.me.displayHexColor);
        message.channel.send(embed);

        // Update mod log
        this.sendModLogMessage(message, reason, { Member: member, Role: role });

      } catch (err) {
        message.client.logger.error(err.stack);
        return this.sendErrorMessage(message, 1, '請檢查身份組層次結構', err.message);
      }
    }  
  }
};
