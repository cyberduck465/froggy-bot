const Command = require('../Command.js');
const { MessageEmbed } = require('discord.js');

module.exports = class KickCommand extends Command {
  constructor(client) {
    super(client, {
      name: 'kick',
      usage: 'kick <user mention/ID> [reason]',
      description: '從你的服務器踢一個成員',
      type: client.types.MOD,
      clientPermissions: ['SEND_MESSAGES', 'EMBED_LINKS', 'KICK_MEMBERS'],
      userPermissions: ['KICK_MEMBERS'],
      examples: ['kick @awa']
    });
  }
  async run(message, args) {

    const member = this.getMemberFromMention(message, args[0]) || message.guild.members.cache.get(args[0]);
    if (!member)
      return this.sendErrorMessage(message, 0, '請提及用戶');
    if (member === message.member) 
      return this.sendErrorMessage(message, 0, '...你不能踼走自己._.'); 
    if (member.roles.highest.position >= message.member.roles.highest.position)
      return this.sendErrorMessage(message, 0, '你不能踼走與你一樣或高於你的身份組');
    if (!member.kickable) 
      return this.sendErrorMessage(message, 0, '這位成員不能被踢走');

    let reason = args.slice(1).join(' ');
    if (!reason) reason = '`None`';
    if (reason.length > 1024) reason = reason.slice(0, 1021) + '...';

    await member.kick(reason);

    const embed = new MessageEmbed()
      .setTitle('Kick Member')
      .setDescription(`${member}成功踼走`)
      .addField('.', message.member, true)
      .addField('成員', member, true)
      .addField('原因', reason)
      .setFooter(message.member.displayName,  message.author.displayAvatarURL({ dynamic: true }))
      .setTimestamp()
      .setColor(message.guild.me.displayHexColor);
    message.channel.send(embed);
    message.client.logger.info(`${message.guild.name}: ${message.author.tag} 踢走 ${member.user.tag}`);
    
    // Update mod log
    this.sendModLogMessage(message, reason, { Member: member});
  }
};
