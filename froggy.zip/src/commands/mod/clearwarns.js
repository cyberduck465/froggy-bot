const Command = require('../Command.js');
const { MessageEmbed } = require('discord.js');
const { oneLine } = require('common-tags');

module.exports = class ClearWarnsCommand extends Command {
  constructor(client) {
    super(client, {
      name: 'clearwarns',
      usage: 'clearwarns <user mention/ID> [reason]',
      description: '清除所提供成員的所有警告。',
      type: client.types.MOD,
      userPermissions: ['KICK_MEMBERS'],
      examples: ['clearwarns @me']
    });
  }
  run(message, args) {

    const member = this.getMemberFromMention(message, args[0]) || message.guild.members.cache.get(args[0]);
    if (!member)
      return this.sendErrorMessage(message, 0, '請提及用戶或提供有效的用戶 ID');
    if (member === message.member) 
      return this.sendErrorMessage(message, 0, '你無法清除自己的警告'); 
    if (member.roles.highest.position >= message.member.roles.highest.position)
      return this.sendErrorMessage(message, 0, '你無法清除具有同等或更高身份組的人的警告');

    let reason = args.slice(1).join(' ');
    if (!reason) reason = '`None`';
    if (reason.length > 1024) reason = reason.slice(0, 1021) + '...';
    
    message.client.db.users.updateWarns.run('', member.id, message.guild.id);

    const embed = new MessageEmbed()
      .setTitle('清除警告')
      .setDescription(`${member} 的警告已成功清除。`)
      .addField('Moderator', message.member, true)
      .addField("成員", member, true)
      .addField('警告統計', '`0`', true)
      .addField('原因', reason)
      .setFooter(message.member.displayName,  message.author.displayAvatarURL({ dynamic: true }))
      .setTimestamp()
      .setColor(message.guild.me.displayHexColor);
    message.channel.send(embed);
    message.client.logger.info(oneLine`
      ${message.guild.name}: ${message.author.tag} 清除 ${member.user.tag}的警告已成功清除。
    `);
    
    // Update mod log
    this.sendModLogMessage(message, reason, { Member: member, '警告統計': '`0`' });
  }
};
